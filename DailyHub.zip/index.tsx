import React, { useCallback, useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  StatusBar,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useFocusEffect } from 'expo-router';
import { subscribeToTasks, toggleTask as updateCloudTask, type DailyTask } from '../../lib/sync';
import { subscribeToProfile, type DailyProfile } from '../../lib/sync';

const C = {
  bg: '#F8F9FD',
  white: '#FFFFFF',
  primary: '#6C63FF',
  text: '#202238',
  muted: '#9699AB',
  border: '#EDF0F5',
};

const dateKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export default function HomeScreen() {
  const [tasks, setTasks] = useState<DailyTask[]>([]);
  const [profile, setProfile] = useState<DailyProfile>({
    name: '',
    notifications: false,
    weekStartsMonday: false,
  });
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(
    dateKey(new Date())
  );
  const [now, setNow] = useState(new Date());

  useFocusEffect(useCallback(() => {
    setLoading(true);
    setNow(new Date());
    const unsubscribeTasks = subscribeToTasks(items => { setTasks(items); setLoading(false); }, error => { console.error(error); setLoading(false); });
    const unsubscribeProfile = subscribeToProfile(setProfile, console.error);
    return () => { unsubscribeTasks(); unsubscribeProfile(); };
  }, []));

  const todayKey = dateKey(now);
  const todayTasks = tasks.filter(t => t.date === todayKey);
  const completed = todayTasks.filter(t => t.done).length;
  const progress = todayTasks.length
    ? completed / todayTasks.length
    : 0;

  const hour = now.getHours();
  const greeting =
    hour < 12
      ? 'Good Morning'
      : hour < 17
      ? 'Good Afternoon'
      : 'Good Evening';

  const firstName = profile.name.trim().split(' ')[0];

  const week = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(now);
    d.setDate(now.getDate() + i - 2);

    return {
      key: dateKey(d),
      number: d.getDate(),
      name: d.toLocaleDateString('en-US', {
        weekday: 'short',
      }),
    };
  });

  const selectedTasks = tasks.filter(
    t => t.date === selectedDate
  );

  const toggleTask = async (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    try { await updateCloudTask(id, !task.done); }
    catch (error) { console.error('Task update failed', error); }
  };

  const formattedDate = now.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });

  const getTaskIcon = (title: string) => {
    const lower = title.toLowerCase();

    if (lower.includes('workout') || lower.includes('gym')) {
      return 'fitness-outline';
    }
    if (lower.includes('meeting') || lower.includes('work')) {
      return 'briefcase-outline';
    }
    if (lower.includes('read') || lower.includes('study')) {
      return 'book-outline';
    }
    return 'checkbox-outline';
  };

  return (
    <SafeAreaView
      style={styles.container}
      edges={['top']}
    >
      <StatusBar barStyle="dark-content" />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.content}
      >
        {/* GREETING */}
        <View style={styles.header}>
          <View style={{ flex: 1 }}>
            <Text style={styles.greeting}>
              {greeting} 
            </Text>

            <Text style={styles.welcome}>
              {firstName
                ? `Let's make today count, ${firstName}!`
                : "Let's make today count!"}
            </Text>
          </View>

          <Pressable
            style={styles.avatar}
            onPress={() => router.push('/profile')}
          >
            <Text style={styles.avatarText}>
              {firstName
                ? firstName[0].toUpperCase()
                : 'D'}
            </Text>
          </Pressable>
        </View>

        <Text style={styles.date}>
          {formattedDate}
        </Text>

        {/* DAILY PROGRESS */}
        <View style={styles.progressCard}>
          <View style={styles.progressTop}>
            <View style={{ flex: 1 }}>
              <Text style={styles.progressTitle}>
                Today's Progress
              </Text>

              <Text style={styles.progressSubtitle}>
                {progress === 1 && todayTasks.length > 0
                  ? 'Amazing! Everything is done.'
                  : 'Keep going! You are doing great.'}
              </Text>
            </View>

            <View style={styles.progressCircle}>
              <Text style={styles.progressPercent}>
                {Math.round(progress * 100)}%
              </Text>
            </View>
          </View>

          <View style={styles.progressTrack}>
            <View
              style={[
                styles.progressFill,
                {
                  width: `${progress * 100}%`,
                },
              ]}
            />
          </View>

          <Text style={styles.progressFooter}>
            {completed} of {todayTasks.length} tasks completed
          </Text>
        </View>

        {/* WEEKLY CALENDAR */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            This Week
          </Text>

          <Pressable
            onPress={() => router.push('/calendar')}
          >
            <Text style={styles.seeAll}>
              View Calendar 
            </Text>
          </Pressable>
        </View>

        <View style={styles.weekRow}>
          {week.map(day => {
            const active = selectedDate === day.key;

            return (
              <Pressable
                key={day.key}
                style={[
                  styles.dayCard,
                  active && styles.activeDay,
                ]}
                onPress={() => setSelectedDate(day.key)}
              >
                <Text
                  style={[
                    styles.dayName,
                    active && styles.activeDayText,
                  ]}
                >
                  {day.name}
                </Text>

                <Text
                  style={[
                    styles.dayNumber,
                    active && styles.activeDayText,
                  ]}
                >
                  {day.number}
                </Text>

                {tasks.some(t => t.date === day.key) && (
                  <View
                    style={[
                      styles.dayDot,
                      active && {
                        backgroundColor: '#FFFFFF',
                      },
                    ]}
                  />
                )}
              </Pressable>
            );
          })}
        </View>

        {/* TASKS */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            {selectedDate === todayKey
              ? "Today's Tasks"
              : 'Scheduled Tasks'}
          </Text>

          <Pressable
            onPress={() => router.push('/tasks')}
          >
            <Text style={styles.seeAll}>
              See All 
            </Text>
          </Pressable>
        </View>

        {loading ? (
          <ActivityIndicator
            color={C.primary}
            style={{ marginVertical: 30 }}
          />
        ) : selectedTasks.length === 0 ? (
          <View style={styles.emptyCard}>
            <View style={styles.emptyIcon}>
              <Ionicons
                name="checkmark-done-outline"
                size={30}
                color={C.primary}
              />
            </View>

            <Text style={styles.emptyTitle}>
              All clear!
            </Text>

            <Text style={styles.emptySubtitle}>
              No tasks scheduled for this day.
            </Text>

            <Pressable
              style={styles.emptyButton}
              onPress={() => router.push('/tasks')}
            >
              <Text style={styles.emptyButtonText}>
                + Add a Task
              </Text>
            </Pressable>
          </View>
        ) : (
          selectedTasks.map((task, index) => {
            const backgrounds = [
              '#EDE9FF',
              '#E4F1FF',
              '#FFF0E2',
              '#E5F7EF',
            ];

            return (
              <Pressable
                key={task.id}
                style={styles.taskCard}
                onPress={() => toggleTask(task.id)}
              >
                <View
                  style={[
                    styles.taskIcon,
                    {
                      backgroundColor:
                        backgrounds[index % backgrounds.length],
                    },
                  ]}
                >
                  <Ionicons
                    name={getTaskIcon(task.title) as any}
                    size={22}
                    color={C.primary}
                  />
                </View>

                <View style={styles.taskInfo}>
                  <Text
                    style={[
                      styles.taskTitle,
                      task.done && styles.completedTask,
                    ]}
                    numberOfLines={2}
                  >
                    {task.title}
                  </Text>

                  <Text style={styles.taskMeta}>
                    {task.date === todayKey
                      ? 'Today'
                      : task.date}
                    {' Â· '}
                    {task.done ? 'Completed' : 'To do'}
                  </Text>
                </View>

                <Ionicons
                  name={
                    task.done
                      ? 'checkmark-circle'
                      : 'ellipse-outline'
                  }
                  size={26}
                  color={
                    task.done
                      ? C.primary
                      : '#CBD0DC'
                  }
                />
              </Pressable>
            );
          })
        )}

        {/* QUICK ACTIONS */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>
            Quick Actions
          </Text>
        </View>

        <View style={styles.actionsRow}>
          <Pressable
            style={styles.actionCard}
            onPress={() => router.push('/tasks')}
          >
            <View
              style={[
                styles.actionIcon,
                { backgroundColor: '#EEE9FF' },
              ]}
            >
              <Ionicons
                name="add"
                size={27}
                color={C.primary}
              />
            </View>

            <Text style={styles.actionText}>
              New Task
            </Text>
          </Pressable>

          <Pressable
            style={styles.actionCard}
            onPress={() => router.push('/notes')}
          >
            <View
              style={[
                styles.actionIcon,
                { backgroundColor: '#FFF0E4' },
              ]}
            >
              <Ionicons
                name="document-text-outline"
                size={24}
                color="#F59E61"
              />
            </View>

            <Text style={styles.actionText}>
              Add Note
            </Text>
          </Pressable>

          <Pressable
            style={styles.actionCard}
            onPress={() => router.push('/calendar')}
          >
            <View
              style={[
                styles.actionIcon,
                { backgroundColor: '#E2F7EC' },
              ]}
            >
              <Ionicons
                name="calendar-outline"
                size={24}
                color="#34B985"
              />
            </View>

            <Text style={styles.actionText}>
              Calendar
            </Text>
          </Pressable>
        </View>

        {/* FOOTER */}
        <View style={styles.footer}>
          <Ionicons
            name="sparkles-outline"
            size={15}
            color={C.primary}
          />
          <Text style={styles.footerText}>
            Small steps, big progress.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bg,
  },

  content: {
    paddingHorizontal: 21,
    paddingTop: 20,
    paddingBottom: 35,
  },

  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 55,
  },

  greeting: {
    fontSize: 17,
    color: C.muted,
    fontWeight: '600',
  },

  welcome: {
    fontSize: 23,
    fontWeight: '800',
    color: C.text,
    marginTop: 6,
  },

  avatar: {
    width: 47,
    height: 47,
    borderRadius: 17,
    backgroundColor: '#E9E5FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 12,
  },

  avatarText: {
    color: C.primary,
    fontSize: 20,
    fontWeight: '900',
  },

  date: {
    fontSize: 14,
    color: C.muted,
    marginTop: 15,
    marginBottom: 24,
  },

  progressCard: {
    backgroundColor: C.primary,
    borderRadius: 24,
    padding: 22,
    marginBottom: 28,
  },

  progressTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  progressTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
  },

  progressSubtitle: {
    color: '#E1DDFF',
    fontSize: 12,
    marginTop: 7,
  },

  progressCircle: {
    width: 66,
    height: 66,
    borderRadius: 33,
    borderWidth: 5,
    borderColor: '#A9A3FF',
    justifyContent: 'center',
    alignItems: 'center',
  },

  progressPercent: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '900',
  },

  progressTrack: {
    height: 8,
    borderRadius: 10,
    backgroundColor: '#938CFF',
    marginTop: 23,
    overflow: 'hidden',
  },

  progressFill: {
    height: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
  },

  progressFooter: {
    color: '#E4E1FF',
    fontSize: 12,
    marginTop: 10,
  },

  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    marginTop: 9,
  },

  sectionTitle: {
    fontSize: 19,
    fontWeight: '800',
    color: C.text,
  },

  seeAll: {
    color: C.primary,
    fontSize: 12,
    fontWeight: '700',
  },

  weekRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 5,
    marginBottom: 27,
  },

  dayCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    alignItems: 'center',
    paddingVertical: 12,
    minHeight: 73,
  },

  activeDay: {
    backgroundColor: C.primary,
  },

  dayName: {
    color: C.muted,
    fontSize: 11,
    fontWeight: '600',
  },

  dayNumber: {
    color: C.text,
    fontSize: 17,
    fontWeight: '800',
    marginTop: 7,
  },

  activeDayText: {
    color: '#FFFFFF',
  },

  dayDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    backgroundColor: C.primary,
    marginTop: 4,
  },

  taskCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 14,
    marginBottom: 11,
    flexDirection: 'row',
    alignItems: 'center',
  },

  taskIcon: {
    width: 49,
    height: 49,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
  },

  taskInfo: {
    flex: 1,
    marginLeft: 13,
  },

  taskTitle: {
    color: C.text,
    fontSize: 15,
    fontWeight: '700',
  },

  completedTask: {
    color: C.muted,
    textDecorationLine: 'line-through',
  },

  taskMeta: {
    color: C.muted,
    fontSize: 12,
    marginTop: 5,
  },

  emptyCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 22,
    padding: 27,
    alignItems: 'center',
    gap: 10,
    marginBottom: 12,
  },

  emptyIcon: {
    backgroundColor: '#EEE9FF',
    width: 58,
    height: 58,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },

  emptyTitle: {
    fontSize: 19,
    fontWeight: '800',
    color: C.text,
  },

  emptySubtitle: {
    color: C.muted,
    fontSize: 13,
    textAlign: 'center',
  },

  emptyButton: {
    backgroundColor: C.primary,
    paddingHorizontal: 22,
    paddingVertical: 12,
    borderRadius: 13,
    marginTop: 8,
  },

  emptyButtonText: {
    color: '#FFFFFF',
    fontWeight: '800',
  },

  actionsRow: {
    flexDirection: 'row',
    gap: 10,
  },

  actionCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    paddingVertical: 18,
    alignItems: 'center',
    gap: 10,
  },

  actionIcon: {
    width: 46,
    height: 46,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center',
  },

  actionText: {
    color: C.text,
    fontSize: 12,
    fontWeight: '700',
  },

  footer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 7,
    marginTop: 28,
  },

  footerText: {
    color: C.muted,
    fontSize: 12,
  },
});
