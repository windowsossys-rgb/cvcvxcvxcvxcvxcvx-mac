DailyHub sync.ts replacement (existing project only)

1. Back up your current src/lib/sync.ts and your app data.
2. Extract this ZIP into C:\Users\Nirav\app\app with overwrite.
3. Run npx tsc --noEmit and test with a disposable task.

Fixes legacy Firestore documents with syncRevision=0, preserves deletion tombstones, and rebases sequential pending changes.
Important: This patch has not been tested against your device or Firebase project. Existing syncConflicts are preserved for manual review.
