import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, TextInput,
  Pressable, Switch, StyleSheet, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { subscribeToProfile, saveProfile, type DailyProfile } from '../../lib/sync';
import { Platform } from 'react-native';

const purple = '#6C63FF';


export default function ProfileScreen() {
  const [profile, setProfile] = useState<DailyProfile>({
    name: 'Nirav',
    notifications: false,
    weekStartsMonday: false,
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => subscribeToProfile(setProfile, console.error), []);

  const update = (changes: Partial<DailyProfile>) => {
    setProfile(previous => ({ ...previous, ...changes }));
    setSaved(false);
  };

  const save = async () => {
    try {
      await saveProfile(profile);
      setSaved(true);
      if (Platform.OS === 'web') window.alert('Your profile has been saved to Firebase.');
      else Alert.alert('Saved!', 'Your profile preferences have been saved.');
    } catch {
      if (Platform.OS === 'web') window.alert('Unable to save your settings.');
      else Alert.alert('Error', 'Unable to save your settings.');
    }
  };

  return (
    <SafeAreaView style={s.root} edges={['top']}>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.kicker}>PERSONAL SPACE</Text>
        <Text style={s.heading}>My Profile </Text>
        <Text style={s.muted}>Make DailyHub your own.</Text>

        <View style={s.profileCard}>
          <View style={s.avatar}>
            <Text style={s.avatarText}>
              {(profile.name.trim()[0] || 'U').toUpperCase()}
            </Text>
          </View>
          <Text style={s.profileName}>{profile.name || 'Your Name'}</Text>
          <Text style={s.profileSubtitle}>DailyHub Member</Text>
        </View>

        <Text style={s.sectionTitle}>Personal Information</Text>
        <View style={s.card}>
          <Text style={s.label}>Display Name</Text>
          <TextInput
            style={s.input}
            value={profile.name}
            onChangeText={name => update({ name })}
            placeholder="Enter your name"
            maxLength={40}
          />
        </View>

        <Text style={s.sectionTitle}>Preferences</Text>
        <View style={s.card}>
          <View style={s.settingRow}>
            <View style={s.settingIcon}>
              <Ionicons name="notifications-outline" size={21} color={purple} />
            </View>
            <View style={s.settingInfo}>
              <Text style={s.settingTitle}>Reminder Preference</Text>
              <Text style={s.settingSubtitle}>
                Save your notification preference
              </Text>
            </View>
            <Switch
              value={profile.notifications}
              onValueChange={v => update({ notifications: v })}
              trackColor={{ false: '#E3E5EE', true: '#B9B3FF' }}
              thumbColor={profile.notifications ? purple : '#FFFFFF'}
            />
          </View>

          <View style={s.separator} />

          <View style={s.settingRow}>
            <View style={s.settingIcon}>
              <Ionicons name="calendar-outline" size={21} color={purple} />
            </View>
            <View style={s.settingInfo}>
              <Text style={s.settingTitle}>Monday First</Text>
              <Text style={s.settingSubtitle}>
                Preferred start of the week
              </Text>
            </View>
            <Switch
              value={profile.weekStartsMonday}
              onValueChange={v => update({ weekStartsMonday: v })}
              trackColor={{ false: '#E3E5EE', true: '#B9B3FF' }}
              thumbColor={profile.weekStartsMonday ? purple : '#FFFFFF'}
            />
          </View>
        </View>

        <Text style={s.sectionTitle}>About</Text>
        <View style={s.card}>
          <View style={s.settingRow}>
            <View style={s.settingIcon}>
              <Ionicons name="information-circle-outline" size={21} color={purple} />
            </View>
            <View style={s.settingInfo}>
              <Text style={s.settingTitle}>DailyHub</Text>
              <Text style={s.settingSubtitle}>Version 1.0.0</Text>
            </View>
          </View>
          <View style={s.separator} />
          <View style={s.settingRow}>
            <View style={s.settingIcon}>
              <Ionicons name="shield-checkmark-outline" size={21} color={purple} />
            </View>
            <View style={s.settingInfo}>
              <Text style={s.settingTitle}>Cloud Sync</Text>
              <Text style={s.settingSubtitle}>
                Tasks, notes and profile stored in Firebase
              </Text>
            </View>
          </View>
        </View>

        <Pressable style={s.saveButton} onPress={save}>
          <Ionicons name="checkmark-circle-outline" size={22} color="white" />
          <Text style={s.saveText}>Save Changes</Text>
        </Pressable>

        <Text style={s.footer}>Made with care for a more organized day.</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8F9FD' },
  content: { padding: 22, gap: 16, paddingBottom: 45 },
  kicker: { color: purple, fontWeight: '800', fontSize: 11, letterSpacing: 2 },
  heading: { color: '#202238', fontSize: 31, fontWeight: '900' },
  muted: { color: '#9699AB', fontSize: 13 },
  profileCard: { backgroundColor: 'white', borderRadius: 24,
    padding: 30, alignItems: 'center', gap: 10, marginTop: 12 },
  avatar: { width: 85, height: 85, borderRadius: 28,
    backgroundColor: '#EEE9FF', alignItems: 'center', justifyContent: 'center' },
  avatarText: { color: purple, fontSize: 36, fontWeight: '900' },
  profileName: { color: '#202238', fontSize: 23, fontWeight: '800' },
  profileSubtitle: { color: '#9699AB', fontSize: 13 },
  sectionTitle: { fontSize: 18, fontWeight: '800', color: '#202238', marginTop: 10 },
  card: { backgroundColor: 'white', borderRadius: 20, padding: 17 },
  label: { color: '#777B91', fontSize: 13, fontWeight: '600', marginBottom: 10 },
  input: { backgroundColor: '#F7F8FC', padding: 16, borderRadius: 12,
    color: '#202238', fontSize: 16 },
  settingRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 10 },
  settingIcon: { backgroundColor: '#EEE9FF', width: 43, height: 43,
    borderRadius: 13, justifyContent: 'center', alignItems: 'center' },
  settingInfo: { flex: 1, gap: 5 },
  settingTitle: { fontWeight: '700', color: '#202238', fontSize: 14 },
  settingSubtitle: { color: '#9699AB', fontSize: 11 },
  separator: { height: 1, backgroundColor: '#F1F2F7', marginVertical: 8 },
  saveButton: { backgroundColor: purple, padding: 18, borderRadius: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    gap: 10, marginTop: 12 },
  saveText: { color: 'white', fontWeight: '800', fontSize: 16 },
  footer: { color: '#B0B3C2', fontSize: 12, textAlign: 'center', marginTop: 15 },
});
