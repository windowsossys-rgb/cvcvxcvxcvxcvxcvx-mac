
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  orderBy,
} from 'firebase/firestore';

import { auth, db } from './firebase';

export type DailyTask = {
  id: string;
  title: string;
  date: string;
  done: boolean;
};

export function subscribeToTasks(
  callback: (tasks: DailyTask[]) => void,
  onError?: (error: Error) => void
) {
  const user = auth.currentUser;

  if (!user) {
    throw new Error('You must be signed in.');
  }

  const tasksRef = collection(db, 'users', user.uid, 'tasks');
  const tasksQuery = query(tasksRef, orderBy('date', 'asc'));

  return onSnapshot(
    tasksQuery,
    snapshot => {
      callback(
        snapshot.docs.map(item => ({
          id: item.id,
          title: item.data().title,
          date: item.data().date,
          done: item.data().done,
        }))
      );
    },
    onError
  );
}

export async function addTask(title: string, date: string) {
  const user = auth.currentUser;

  if (!user) throw new Error('You must be signed in.');

  return addDoc(collection(db, 'users', user.uid, 'tasks'), {
    title: title.trim(),
    date,
    done: false,
  });
}

export async function toggleTask(id: string, done: boolean) {
  const user = auth.currentUser;

  if (!user) throw new Error('You must be signed in.');

  return updateDoc(doc(db, 'users', user.uid, 'tasks', id), {
    done,
  });
}

export async function deleteTask(id: string) {
  const user = auth.currentUser;

  if (!user) throw new Error('You must be signed in.');

  return deleteDoc(doc(db, 'users', user.uid, 'tasks', id));
}
