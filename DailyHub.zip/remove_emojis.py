﻿import pathlib
import re
import shutil
import unicodedata

root = pathlib.Path.cwd()
extensions = {".tsx", ".ts", ".jsx", ".js", ".json", ".html", ".css"}
excluded = {"node_modules", ".git", ".expo", "dist", "build", "coverage"}

# Emoji Unicode ranges, including symbols frequently used as emoji
emoji = re.compile(
    "[\U0001F000-\U0001FAFF"
    "\u2600-\u27BF"
    "\uFE0F"
    "\u200D]"
)

# Broken emoji sequences produced by incorrect UTF-8 decoding
mojibake = re.compile(
    r"(?:ðŸ|âœ|âš|â˜|â|âž)[^\s'\"<>]{0,12}"
)

changed = 0

for path in root.rglob("*"):
    if not path.is_file() or path.suffix.lower() not in extensions:
        continue
    if any(part in excluded for part in path.relative_to(root).parts):
        continue

    try:
        original = path.read_text(encoding="utf-8")
    except UnicodeError:
        print("SKIPPED invalid UTF-8:", path)
        continue

    cleaned = emoji.sub("", original)
    cleaned = mojibake.sub("", cleaned)

    if cleaned != original:
        shutil.copy2(path, path.with_suffix(path.suffix + ".emoji-backup"))
        path.write_text(cleaned, encoding="utf-8")
        print("CLEANED:", path.relative_to(root))
        changed += 1

print(f"Finished. Modified {changed} files. Backups created.")
