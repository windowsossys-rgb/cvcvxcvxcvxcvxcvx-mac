// TypeScript fallback; Metro selects remember.web.ts / remember.native.ts per platform.
export { setRememberMe } from './remember.web';
