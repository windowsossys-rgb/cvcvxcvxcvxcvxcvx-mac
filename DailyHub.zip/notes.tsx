import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, ScrollView, Pressable,
  StyleSheet, Alert, Modal, KeyboardAvoidingView, Platform,
  Keyboard, ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { subscribeToNotes, addNote, updateNote, removeNote, type DailyNote } from '../../lib/sync';

const purple = '#6C63FF';

export default function NotesScreen() {
  const [notes, setNotes] = useState<DailyNote[]>([]);
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<DailyNote | null>(null);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [keyboardOpen, setKeyboardOpen] = useState(false);
  const insets = useSafeAreaInsets();

  useEffect(() => subscribeToNotes(
    items => { setNotes(items); setLoaded(true); },
    error => { console.error(error); setLoaded(true); }
  ), []);

  useEffect(() => {
    const show = Keyboard.addListener('keyboardDidShow', () => setKeyboardOpen(true));
    const hide = Keyboard.addListener('keyboardDidHide', () => setKeyboardOpen(false));
    return () => { show.remove(); hide.remove(); };
  }, []);

  const create = () => {
    setEditing(null);
    setTitle('');
    setBody('');
    setOpen(true);
  };

  const edit = (note: DailyNote) => {
    setEditing(note);
    setTitle(note.title);
    setBody(note.body);
    setOpen(true);
  };

  const showMessage = (heading: string, message: string) => {
    if (Platform.OS === 'web') window.alert(`${heading}: ${message}`);
    else Alert.alert(heading, message);
  };

  const saveNote = async () => {
    if (saving) return;
    if (!title.trim() && !body.trim()) {
      showMessage('Empty note', 'Write something first.');
      return;
    }
    setSaving(true);
    try {
      if (editing) await updateNote(editing.id, title.trim() || 'Untitled Note', body.trim());
      else await addNote(title.trim() || 'Untitled Note', body.trim());
      Keyboard.dismiss();
      setOpen(false);
    } catch (error) {
      console.error(error);
      showMessage('Save failed', 'Could not save note to Firebase.');
    } finally {
      setSaving(false);
    }
  };

  const deleteNote = () => {
    if (!editing || saving) return;
    const id = editing.id;
    const performDelete = async () => {
      try {
        await removeNote(id);
        Keyboard.dismiss();
        setOpen(false);
      } catch (error) {
        console.error(error);
        showMessage('Delete failed', 'Could not delete note.');
      }
    };
    if (Platform.OS === 'web') {
      if (window.confirm('Delete this note?')) void performDelete();
    } else {
      Alert.alert('Delete note?', 'This cannot be undone.', [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => void performDelete() },
      ]);
    }
  };

  const visible = notes
    .filter(n => `${n.title} ${n.body}`.toLowerCase().includes(search.toLowerCase()))
    .sort((a, b) => b.updatedAt - a.updatedAt);

  return (
    <SafeAreaView style={s.root} edges={['top']}>
      <ScrollView contentContainerStyle={s.content} keyboardShouldPersistTaps="handled">
        <Text style={s.kicker}>CAPTURE YOUR THOUGHTS</Text>
        <Text style={s.heading}>My Notes</Text>
        <Text style={s.muted}>Every great idea starts somewhere.</Text>

        <View style={s.searchBox}>
          <Ionicons name="search-outline" size={21} color="#9699AB" />
          <TextInput
            style={s.searchInput}
            placeholder="Search your notes..."
            placeholderTextColor="#9699AB"
            value={search}
            onChangeText={setSearch}
          />
        </View>

        <Pressable style={s.addButton} onPress={create}>
          <Ionicons name="add" size={22} color="white" />
          <Text style={s.addText}>Create New Note</Text>
        </Pressable>

        <Text style={s.sectionTitle}>All Notes ({visible.length})</Text>

        {!loaded ? <Text style={s.muted}>Loading...</Text> :
          visible.length === 0 ? (
            <View style={s.empty}>
              <Ionicons name="document-text-outline" size={42} color={purple} />
              <Text style={s.emptyTitle}>No notes found</Text>
              <Text style={s.muted}>Create your first note to get started.</Text>
            </View>
          ) : visible.map(note => (
            <Pressable key={note.id} style={s.noteCard} onPress={() => edit(note)}>
              <View style={s.noteIcon}>
                <Ionicons name="document-text-outline" size={22} color={purple} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.noteTitle} numberOfLines={1}>{note.title}</Text>
                <Text style={s.notePreview} numberOfLines={2}>{note.body || 'Empty note'}</Text>
                <Text style={s.noteDate}>{new Date(note.updatedAt).toLocaleDateString()}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#B5B8C8" />
            </Pressable>
          ))}
      </ScrollView>

      <Modal visible={open} animationType="slide" onRequestClose={() => { if (!saving) setOpen(false); }}>
        <SafeAreaView style={s.root} edges={['top']}>
          <KeyboardAvoidingView
            style={s.editorLayout}
            behavior={Platform.OS === 'ios' ? 'padding' : Platform.OS === 'android' ? 'height' : undefined}
            keyboardVerticalOffset={0}
          >
            <View style={s.editorHeader}>
              <Pressable onPress={() => { if (!saving) { Keyboard.dismiss(); setOpen(false); } }} disabled={saving}>
                <Text style={s.cancel}>Cancel</Text>
              </Pressable>
              <Text style={s.editorHeading}>{editing ? 'Edit Note' : 'New Note'}</Text>
              <View style={{ width: 52 }} />
            </View>

            <TextInput
              style={s.titleInput}
              placeholder="Note title"
              placeholderTextColor="#9699AB"
              value={title}
              onChangeText={setTitle}
              maxLength={100}
              returnKeyType="next"
            />
            <TextInput
              style={s.bodyInput}
              placeholder="Start writing..."
              placeholderTextColor="#9699AB"
              value={body}
              onChangeText={setBody}
              multiline
              scrollEnabled
              textAlignVertical="top"
            />

            <View style={[s.bottomBar, { paddingBottom: keyboardOpen ? 10 : Math.max(insets.bottom, 12) }]}>
              {editing && (
                <Pressable style={s.deleteButton} onPress={deleteNote} disabled={saving}>
                  <Ionicons name="trash-outline" size={19} color="#F47A87" />
                  <Text style={s.deleteText}>Delete</Text>
                </Pressable>
              )}
              <Pressable
                style={[s.saveButton, saving && s.disabledButton]}
                onPress={saveNote}
                disabled={saving}
                accessibilityRole="button"
                accessibilityLabel="Save note"
              >
                {saving ? <ActivityIndicator color="white" /> : <Ionicons name="checkmark" size={21} color="white" />}
                <Text style={s.saveButtonText}>{saving ? 'Saving...' : 'Save Note'}</Text>
              </Pressable>
            </View>
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8F9FD' },
  content: { padding: 22, gap: 16 },
  kicker: { color: purple, fontWeight: '800', fontSize: 11, letterSpacing: 2 },
  heading: { color: '#202238', fontSize: 31, fontWeight: '900' },
  muted: { color: '#9699AB', fontSize: 13 },
  searchBox: { backgroundColor: 'white', borderRadius: 16,
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, marginTop: 14 },
  searchInput: { flex: 1, padding: 17, color: '#202238' },
  addButton: { backgroundColor: purple, padding: 17, borderRadius: 16,
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  addText: { color: 'white', fontWeight: '800', fontSize: 15 },
  sectionTitle: { color: '#202238', fontSize: 19, fontWeight: '800', marginTop: 10 },
  noteCard: { backgroundColor: 'white', padding: 17, borderRadius: 19,
    flexDirection: 'row', alignItems: 'center', gap: 14 },
  noteIcon: { backgroundColor: '#EEE9FF', padding: 13, borderRadius: 14 },
  noteTitle: { fontSize: 16, fontWeight: '800', color: '#202238' },
  notePreview: { color: '#777B91', fontSize: 13, marginTop: 5 },
  noteDate: { color: '#B0B3C2', fontSize: 11, marginTop: 8 },
  empty: { backgroundColor: 'white', padding: 40, borderRadius: 20,
    alignItems: 'center', gap: 12 },
  emptyTitle: { fontWeight: '800', color: '#202238', fontSize: 17 },
  editorLayout: { flex: 1 },
  editorHeader: { flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', paddingHorizontal: 22, paddingVertical: 20 },
  editorHeading: { fontSize: 17, fontWeight: '800', color: '#202238' },
  cancel: { color: '#9699AB', fontSize: 15 },
  titleInput: { marginHorizontal: 22, fontSize: 27, fontWeight: '800',
    color: '#202238', paddingVertical: 16 },
  bodyInput: { flex: 1, minHeight: 80, marginHorizontal: 22, fontSize: 16,
    lineHeight: 25, color: '#202238', paddingTop: 8 },
  bottomBar: { flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: '#FFFFFF', paddingTop: 12, paddingHorizontal: 18,
    borderTopWidth: 1, borderTopColor: '#EDF0F5' },
  saveButton: { flex: 1, backgroundColor: purple, borderRadius: 14,
    paddingVertical: 15, flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', gap: 8 },
  disabledButton: { opacity: 0.6 },
  saveButtonText: { color: 'white', fontWeight: '800', fontSize: 16 },
  deleteButton: { flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 10, paddingVertical: 12 },
  deleteText: { color: '#F47A87', fontWeight: '700' },
});
