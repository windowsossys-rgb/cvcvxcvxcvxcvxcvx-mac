
import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, ScrollView, Pressable,
  StyleSheet, Alert, Modal, KeyboardAvoidingView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';

type Note = {
  id: string;
  title: string;
  body: string;
  updatedAt: number;
};

const KEY = 'dailyhub_notes';
const purple = '#6C63FF';

export default function NotesScreen() {
  const [notes, setNotes] = useState<Note[]>([]);
  const [search, setSearch] = useState('');
  const [editing, setEditing] = useState<Note | null>(null);
  const [open, setOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem(KEY).then(raw => {
      setNotes(raw ? JSON.parse(raw) : []);
      setLoaded(true);
    }).catch(() => setLoaded(true));
  }, []);

  const saveAll = async (next: Note[]) => {
    setNotes(next);
    try {
      await AsyncStorage.setItem(KEY, JSON.stringify(next));
    } catch {
      Alert.alert('Save failed', 'Could not save your notes.');
    }
  };

  const create = () => {
    setEditing(null);
    setTitle('');
    setBody('');
    setOpen(true);
  };

  const edit = (note: Note) => {
    setEditing(note);
    setTitle(note.title);
    setBody(note.body);
    setOpen(true);
  };

  const saveNote = () => {
    if (!title.trim() && !body.trim()) {
      Alert.alert('Empty note', 'Write something first.');
      return;
    }

    const note: Note = {
      id: editing?.id ?? `${Date.now()}-${Math.random()}`,
      title: title.trim() || 'Untitled Note',
      body: body.trim(),
      updatedAt: Date.now(),
    };

    const next = editing
      ? notes.map(n => n.id === editing.id ? note : n)
      : [note, ...notes];

    saveAll(next);
    setOpen(false);
  };

  const deleteNote = () => {
    if (!editing) return;
    Alert.alert('Delete note?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => {
        saveAll(notes.filter(n => n.id !== editing.id));
        setOpen(false);
      }},
    ]);
  };

  const visible = notes
    .filter(n =>
      `${n.title} ${n.body}`.toLowerCase().includes(search.toLowerCase())
    )
    .sort((a, b) => b.updatedAt - a.updatedAt);

  return (
    <SafeAreaView style={s.root} edges={['top']}>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.kicker}>CAPTURE YOUR THOUGHTS</Text>
        <Text style={s.heading}>My Notes </Text>
        <Text style={s.muted}>Every great idea starts somewhere.</Text>

        <View style={s.searchBox}>
          <Ionicons name="search-outline" size={21} color="#9699AB" />
          <TextInput
            style={s.searchInput}
            placeholder="Search your notes..."
            placeholderTextColor="#9699AB"
            value={search}
            onChangeText={setSearch}
          />
        </View>

        <Pressable style={s.addButton} onPress={create}>
          <Ionicons name="add" size={22} color="white" />
          <Text style={s.addText}>Create New Note</Text>
        </Pressable>

        <Text style={s.sectionTitle}>All Notes ({visible.length})</Text>

        {!loaded ? <Text style={s.muted}>Loading...</Text> :
          visible.length === 0 ? (
          <View style={s.empty}>
            <Ionicons name="document-text-outline" size={42} color={purple} />
            <Text style={s.emptyTitle}>No notes found</Text>
            <Text style={s.muted}>Create your first note to get started.</Text>
          </View>
        ) : visible.map(note => (
          <Pressable key={note.id} style={s.noteCard} onPress={() => edit(note)}>
            <View style={s.noteIcon}>
              <Ionicons name="document-text-outline" size={22} color={purple} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={s.noteTitle} numberOfLines={1}>{note.title}</Text>
              <Text style={s.notePreview} numberOfLines={2}>{note.body || 'Empty note'}</Text>
              <Text style={s.noteDate}>
                {new Date(note.updatedAt).toLocaleDateString()}
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color="#B5B8C8" />
          </Pressable>
        ))}
      </ScrollView>

      <Modal visible={open} animationType="slide" onRequestClose={() => setOpen(false)}>
        <SafeAreaView style={s.root}>
          <KeyboardAvoidingView
            style={{ flex: 1 }}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
          >
            <View style={s.editorHeader}>
              <Pressable onPress={() => setOpen(false)}>
                <Text style={s.cancel}>Cancel</Text>
              </Pressable>
              <Text style={s.editorHeading}>{editing ? 'Edit Note' : 'New Note'}</Text>
              <Pressable onPress={saveNote}>
                <Text style={s.save}>Save</Text>
              </Pressable>
            </View>
            <TextInput
              style={s.titleInput}
              placeholder="Note title"
              placeholderTextColor="#9699AB"
              value={title}
              onChangeText={setTitle}
              maxLength={100}
            />
            <TextInput
              style={s.bodyInput}
              placeholder="Start writing..."
              placeholderTextColor="#9699AB"
              value={body}
              onChangeText={setBody}
              multiline
              textAlignVertical="top"
            />
            {editing && (
              <Pressable style={s.deleteButton} onPress={deleteNote}>
                <Ionicons name="trash-outline" size={19} color="#F47A87" />
                <Text style={{ color: '#F47A87', fontWeight: '700' }}>Delete Note</Text>
              </Pressable>
            )}
          </KeyboardAvoidingView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8F9FD' },
  content: { padding: 22, gap: 16 },
  kicker: { color: purple, fontWeight: '800', fontSize: 11, letterSpacing: 2 },
  heading: { color: '#202238', fontSize: 31, fontWeight: '900' },
  muted: { color: '#9699AB', fontSize: 13 },
  searchBox: { backgroundColor: 'white', borderRadius: 16,
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, marginTop: 14 },
  searchInput: { flex: 1, padding: 17, color: '#202238' },
  addButton: { backgroundColor: purple, padding: 17, borderRadius: 16,
    flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8 },
  addText: { color: 'white', fontWeight: '800', fontSize: 15 },
  sectionTitle: { color: '#202238', fontSize: 19, fontWeight: '800', marginTop: 10 },
  noteCard: { backgroundColor: 'white', padding: 17, borderRadius: 19,
    flexDirection: 'row', alignItems: 'center', gap: 14 },
  noteIcon: { backgroundColor: '#EEE9FF', padding: 13, borderRadius: 14 },
  noteTitle: { fontSize: 16, fontWeight: '800', color: '#202238' },
  notePreview: { color: '#777B91', fontSize: 13, marginTop: 5 },
  noteDate: { color: '#B0B3C2', fontSize: 11, marginTop: 8 },
  empty: { backgroundColor: 'white', padding: 40, borderRadius: 20,
    alignItems: 'center', gap: 12 },
  emptyTitle: { fontWeight: '800', color: '#202238', fontSize: 17 },
  editorHeader: { flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', padding: 22 },
  editorHeading: { fontSize: 17, fontWeight: '800', color: '#202238' },
  cancel: { color: '#9699AB', fontSize: 15 },
  save: { color: purple, fontWeight: '800', fontSize: 16 },
  titleInput: { marginHorizontal: 22, fontSize: 27, fontWeight: '800',
    color: '#202238', paddingVertical: 16 },
  bodyInput: { flex: 1, marginHorizontal: 22, fontSize: 16,
    lineHeight: 25, color: '#202238' },
  deleteButton: { flexDirection: 'row', alignItems: 'center',
    justifyContent: 'center', padding: 22, gap: 8 },
});
