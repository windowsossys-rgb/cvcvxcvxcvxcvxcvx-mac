import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, Pressable, StyleSheet,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { subscribeToTasks, type DailyTask } from '../../lib/sync';

const purple = '#6C63FF';
const dateKey = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

export default function CalendarScreen() {
  const [selected, setSelected] = useState(new Date());
  const [month, setMonth] = useState(new Date());
  const [tasks, setTasks] = useState<DailyTask[]>([]);

  useEffect(() => {
    const unsubscribe = subscribeToTasks(setTasks, error => console.error('Calendar sync:', error));
    return unsubscribe;
  }, []);

  const year = month.getFullYear();
  const monthIndex = month.getMonth();
  const count = new Date(year, monthIndex + 1, 0).getDate();
  const offset = new Date(year, monthIndex, 1).getDay();
  const cells = [
    ...Array(offset).fill(null),
    ...Array.from({ length: count }, (_, i) => i + 1),
  ];
  const selectedKey = dateKey(selected);
  const selectedTasks = tasks.filter(t => t.date === selectedKey);

  const changeMonth = (direction: number) => {
    const next = new Date(year, monthIndex + direction, 1);
    setMonth(next);
    setSelected(next);
  };

  return (
    <SafeAreaView style={s.root} edges={['top']}>
      <ScrollView contentContainerStyle={s.content}>
        <Text style={s.kicker}>YOUR SCHEDULE</Text>
        <Text style={s.heading}>Calendar </Text>
        <Text style={s.muted}>Plan ahead, stay organized.</Text>

        <View style={s.card}>
          <View style={s.monthHeader}>
            <Pressable onPress={() => changeMonth(-1)}>
              <Ionicons name="chevron-back" size={24} color={purple} />
            </Pressable>
            <Text style={s.monthTitle}>
              {month.toLocaleDateString('en-US', {
                month: 'long', year: 'numeric',
              })}
            </Text>
            <Pressable onPress={() => changeMonth(1)}>
              <Ionicons name="chevron-forward" size={24} color={purple} />
            </Pressable>
          </View>

          <View style={s.calendarGrid}>
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
              <View key={i} style={s.dayCell}>
                <Text style={s.weekday}>{d}</Text>
              </View>
            ))}

            {cells.map((day, i) => {
              const current = day
                ? new Date(year, monthIndex, day)
                : null;
              const keyForDay = current ? dateKey(current) : '';
              const active = keyForDay === selectedKey;
              const hasTasks = tasks.some(t => t.date === keyForDay);
              return (
                <Pressable
                  key={i}
                  disabled={!day}
                  onPress={() => current && setSelected(current)}
                  style={s.dayCell}
                >
                  <View style={[s.dayBubble, active && s.activeDay]}>
                    <Text style={[s.dayText, active && { color: 'white' }]}>
                      {day || ''}
                    </Text>
                  </View>
                  {day && hasTasks && <View style={s.dot} />}
                </Pressable>
              );
            })}
          </View>
        </View>

        <View style={s.sectionRow}>
          <Text style={s.sectionTitle}>
            {selected.toLocaleDateString('en-US', {
              month: 'short', day: 'numeric',
            })}
          </Text>
          <Pressable onPress={() => router.push('/tasks')}>
            <Text style={s.link}>Manage Tasks </Text>
          </Pressable>
        </View>

        {selectedTasks.length === 0 ? (
          <View style={s.emptyCard}>
            <Ionicons name="calendar-clear-outline" size={34} color={purple} />
            <Text style={s.emptyTitle}>Nothing scheduled</Text>
            <Text style={s.muted}>Enjoy your free time!</Text>
          </View>
        ) : selectedTasks.map(task => (
          <View key={task.id} style={s.event}>
            <View style={s.eventStripe} />
            <View style={{ flex: 1 }}>
              <Text style={s.eventTitle}>{task.title}</Text>
              <Text style={s.muted}>
                {task.done ? 'Completed' : 'To do'}
              </Text>
            </View>
            <Ionicons
              name={task.done ? 'checkmark-circle' : 'time-outline'}
              size={22}
              color={purple}
            />
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#F8F9FD' },
  content: { padding: 22, gap: 16 },
  kicker: { color: purple, fontWeight: '800', fontSize: 11, letterSpacing: 2 },
  heading: { fontSize: 31, fontWeight: '900', color: '#202238' },
  muted: { color: '#9699AB', fontSize: 13 },
  card: { backgroundColor: 'white', padding: 16, borderRadius: 24, marginTop: 12 },
  monthHeader: { flexDirection: 'row', alignItems: 'center',
    justifyContent: 'space-between', paddingVertical: 14 },
  monthTitle: { fontSize: 19, fontWeight: '800', color: '#202238' },
  calendarGrid: { flexDirection: 'row', flexWrap: 'wrap' },
  dayCell: { width: '14.2857%', height: 55, alignItems: 'center', justifyContent: 'center' },
  weekday: { color: '#9699AB', fontWeight: '700' },
  dayBubble: { width: 39, height: 39, borderRadius: 13,
    alignItems: 'center', justifyContent: 'center' },
  activeDay: { backgroundColor: purple },
  dayText: { fontSize: 15, color: '#202238', fontWeight: '600' },
  dot: { position: 'absolute', bottom: 2, width: 5, height: 5,
    borderRadius: 3, backgroundColor: '#A49BFF' },
  sectionRow: { flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginTop: 15 },
  sectionTitle: { fontSize: 19, fontWeight: '800', color: '#202238' },
  link: { color: purple, fontSize: 12, fontWeight: '700' },
  emptyCard: { backgroundColor: 'white', padding: 36, borderRadius: 20,
    alignItems: 'center', gap: 12 },
  emptyTitle: { color: '#202238', fontSize: 17, fontWeight: '800' },
  event: { backgroundColor: 'white', borderRadius: 17, padding: 17,
    flexDirection: 'row', alignItems: 'center', gap: 12 },
  eventStripe: { width: 4, height: 40, borderRadius: 4, backgroundColor: purple },
  eventTitle: { color: '#202238', fontWeight: '700', fontSize: 15 },
});
