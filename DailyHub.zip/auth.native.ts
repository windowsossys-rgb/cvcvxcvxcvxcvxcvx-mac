
import {
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
} from 'firebase/auth';

import { auth } from './firebase.native';

// Sign in with email and password
export async function loginWithEmail(
  email: string,
  password: string
) {
  const result = await signInWithEmailAndPassword(
    auth,
    email.trim(),
    password
  );

  return result.user;
}

// Create a new account
export async function registerWithEmail(
  email: string,
  password: string
) {
  const result = await createUserWithEmailAndPassword(
    auth,
    email.trim(),
    password
  );

  return result.user;
}

// Send a password reset email
export async function resetPassword(email: string) {
  await sendPasswordResetEmail(auth, email.trim());
}

// Google Sign-In requires a custom native build.
// It is not supported in standard Expo Go.
export async function loginWithGoogle() {
  throw new Error(
    'Google Sign-In is unavailable in Expo Go. Please use email and password.'
  );
}

// Sign out
export async function logout() {
  await signOut(auth);
}
