
import {
  GoogleAuthProvider,
  signInWithCredential,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
} from 'firebase/auth';

import {
  GoogleSignin,
  isSuccessResponse,
} from '@react-native-google-signin/google-signin';

import { auth } from './firebase';

GoogleSignin.configure({
  webClientId: process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID,
});

export const loginWithEmail = (email: string, password: string) =>
  signInWithEmailAndPassword(auth, email.trim(), password);

export const registerWithEmail = (email: string, password: string) =>
  createUserWithEmailAndPassword(auth, email.trim(), password);

export const resetPassword = (email: string) =>
  sendPasswordResetEmail(auth, email.trim());

export const loginWithGoogle = async () => {
  const response = await GoogleSignin.signIn();

  if (!isSuccessResponse(response)) return null;

  const idToken = response.data.idToken;
  if (!idToken) throw new Error('Google ID token was not returned.');

  return signInWithCredential(
    auth,
    GoogleAuthProvider.credential(idToken)
  );
};

export const logout = async () => {
  await signOut(auth);
  await GoogleSignin.signOut().catch(() => {});
};
