
import {
  collection,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  orderBy,
  serverTimestamp,
} from 'firebase/firestore';

import { auth, db } from './firebase';

export type DailyNote = {
  id: string;
  title: string;
  content: string;
  updatedAt?: unknown;
};

function notesCollection() {
  const user = auth.currentUser;

  if (!user) {
    throw new Error('You must be signed in.');
  }

  return collection(db, 'users', user.uid, 'notes');
}

export function subscribeToNotes(
  callback: (notes: DailyNote[]) => void,
  onError?: (error: Error) => void
) {
  const q = query(
    notesCollection(),
    orderBy('updatedAt', 'desc')
  );

  return onSnapshot(
    q,
    snapshot => {
      callback(
        snapshot.docs.map(item => ({
          id: item.id,
          title: item.data().title ?? '',
          content: item.data().content ?? '',
          updatedAt: item.data().updatedAt,
        }))
      );
    },
    onError
  );
}

export async function addNote(
  title: string,
  content: string
) {
  return addDoc(notesCollection(), {
    title: title.trim(),
    content,
    updatedAt: serverTimestamp(),
  });
}

export async function updateNote(
  id: string,
  title: string,
  content: string
) {
  const ref = doc(notesCollection(), id);

  return updateDoc(ref, {
    title: title.trim(),
    content,
    updatedAt: serverTimestamp(),
  });
}

export async function deleteNote(id: string) {
  return deleteDoc(doc(notesCollection(), id));
}
