
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  Pressable,
  StyleSheet,
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import {
  loginWithEmail,
  registerWithEmail,
  loginWithGoogle,
  resetPassword,
} from '../lib/auth';

const PURPLE = '#6C63FF';

export default function LoginScreen() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [registering, setRegistering] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleEmail = async () => {
    if (!email.trim() || !password) {
      Alert.alert('Missing information', 'Enter your email and password.');
      return;
    }

    if (registering && password.length < 6) {
      Alert.alert('Password too short', 'Use at least 6 characters.');
      return;
    }

    setLoading(true);

    try {
      if (registering) {
        await registerWithEmail(email, password);
      } else {
        await loginWithEmail(email, password);
      }
      // Root layout automatically switches to Home after login.
    } catch (error: any) {
      const message = error?.message || 'Please try again.';
      if (Platform.OS === 'web') {
        window.alert(message);
      } else {
        Alert.alert('Authentication error', message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    setLoading(true);

    try {
      await loginWithGoogle();
    } catch (error: any) {
      const message = error?.message || 'Google sign-in failed.';
      if (Platform.OS === 'web') {
        window.alert(message);
      } else {
        Alert.alert('Google Sign-In', message);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleReset = async () => {
    if (!email.trim()) {
      const message = 'Enter your email address first.';
      if (Platform.OS === 'web') window.alert(message);
      else Alert.alert('Email required', message);
      return;
    }

    try {
      await resetPassword(email);
      const message = 'If an account exists, password reset instructions will be sent.';
      if (Platform.OS === 'web') window.alert(message);
      else Alert.alert('Check your email', message);
    } catch (error: any) {
      const message = error?.message || 'Unable to reset password.';
      if (Platform.OS === 'web') window.alert(message);
      else Alert.alert('Error', message);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <ScrollView
          contentContainerStyle={styles.content}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.logo}>
            <Ionicons name="layers-outline" size={36} color={PURPLE} />
          </View>

          <Text style={styles.title}>DailyHub</Text>
          <Text style={styles.subtitle}>
            Your day, organized beautifully.
          </Text>

          <Text style={styles.heading}>
            {registering ? 'Create your account' : 'Welcome back'}
          </Text>

          <Text style={styles.description}>
            {registering
              ? 'Sign up to get started with DailyHub.'
              : 'Sign in to access your daily workspace.'}
          </Text>

          <Text style={styles.label}>Email Address</Text>
          <TextInput
            style={styles.input}
            placeholder="you@example.com"
            placeholderTextColor="#A0A3B5"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
            autoComplete="email"
          />

          <Text style={styles.label}>Password</Text>
          <TextInput
            style={styles.input}
            placeholder="Enter your password"
            placeholderTextColor="#A0A3B5"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
            autoComplete={registering ? 'new-password' : 'current-password'}
          />

          {!registering && (
            <Pressable onPress={handleReset} disabled={loading}>
              <Text style={styles.forgot}>Forgot password?</Text>
            </Pressable>
          )}

          <Pressable
            style={[styles.primaryButton, loading && { opacity: 0.6 }]}
            onPress={handleEmail}
            disabled={loading}
          >
            {loading ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <Text style={styles.primaryText}>
                {registering ? 'Create Account' : 'Sign In'}
              </Text>
            )}
          </Pressable>

          <View style={styles.dividerRow}>
            <View style={styles.divider} />
            <Text style={styles.orText}>OR</Text>
            <View style={styles.divider} />
          </View>

          <Pressable
            style={styles.googleButton}
            onPress={handleGoogle}
            disabled={loading}
          >
            <Ionicons name="logo-google" size={21} color="#4285F4" />
            <Text style={styles.googleText}>Continue with Google</Text>
          </Pressable>

          <Pressable
            style={styles.switchButton}
            onPress={() => setRegistering(!registering)}
            disabled={loading}
          >
            <Text style={styles.switchText}>
              {registering
                ? 'Already have an account? Sign In'
                : "Don't have an account? Sign Up"}
            </Text>
          </Pressable>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FD',
  },
  content: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 26,
    paddingVertical: 45,
    width: '100%',
    maxWidth: 460,
    alignSelf: 'center',
  },
  logo: {
    width: 76,
    height: 76,
    borderRadius: 24,
    backgroundColor: '#ECEAFF',
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: 15,
  },
  title: {
    fontSize: 32,
    fontWeight: '900',
    color: '#22243A',
    textAlign: 'center',
  },
  subtitle: {
    color: '#9699AB',
    textAlign: 'center',
    marginTop: 5,
    marginBottom: 38,
  },
  heading: {
    fontSize: 25,
    fontWeight: '800',
    color: '#22243A',
    marginBottom: 8,
  },
  description: {
    color: '#9699AB',
    fontSize: 14,
    marginBottom: 25,
  },
  label: {
    color: '#33354B',
    fontWeight: '700',
    marginBottom: 8,
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#ECEEF5',
    paddingHorizontal: 16,
    paddingVertical: 15,
    fontSize: 15,
    color: '#22243A',
    marginBottom: 18,
  },
  forgot: {
    color: PURPLE,
    textAlign: 'right',
    fontWeight: '700',
    marginBottom: 22,
  },
  primaryButton: {
    backgroundColor: PURPLE,
    borderRadius: 15,
    paddingVertical: 17,
    alignItems: 'center',
    marginTop: 8,
  },
  primaryText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  dividerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginVertical: 25,
  },
  divider: {
    flex: 1,
    height: 1,
    backgroundColor: '#E5E7F0',
  },
  orText: {
    color: '#9699AB',
    fontWeight: '600',
  },
  googleButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 15,
    borderWidth: 1,
    borderColor: '#E5E7F0',
    paddingVertical: 16,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  googleText: {
    color: '#22243A',
    fontSize: 15,
    fontWeight: '700',
  },
  switchButton: {
    paddingVertical: 22,
  },
  switchText: {
    color: PURPLE,
    textAlign: 'center',
    fontWeight: '700',
  },
});
