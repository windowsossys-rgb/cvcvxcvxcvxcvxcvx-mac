
export {
  loginWithEmail,
  registerWithEmail,
  loginWithGoogle,
  resetPassword,
  logout,
} from './auth.web';
