import AsyncStorage from '@react-native-async-storage/async-storage';
import { auth, db } from './firebase';
import {
  collection, doc, onSnapshot, runTransaction, serverTimestamp,
  type Unsubscribe,
} from 'firebase/firestore';

type Kind = 'tasks' | 'notes' | 'profile';
type RecordData = { id: string; [key: string]: any };
type Change = { id: string; data: RecordData | null; base: number; op: string };
type State = { records: RecordData[]; pending: Change[]; imported: boolean };
const legacyKeys: Record<Kind, string> = {
  tasks: 'dailyhub_tasks', notes: 'dailyhub_notes', profile: 'dailyhub_profile',
};
const channels = new Map<string, Channel>();
const randomId = () => `${Date.now()}-${Math.random().toString(36).slice(2)}`;
const clean = (item: RecordData): RecordData => {
  const out: RecordData = { id: String(item.id) };
  for (const [key, value] of Object.entries(item)) {
    if (!['id', '_rev', 'deleted', 'serverUpdatedAt', 'syncRevision'].includes(key) && value !== undefined) out[key] = value;
  }
  return out;
};
const equal = (a: RecordData, b: RecordData) => JSON.stringify(clean(a)) === JSON.stringify(clean(b));

class Channel {
  private state: State = { records: [], pending: [], imported: false };
  private listeners = new Set<(rows: RecordData[]) => void>();
  private errors = new Set<(e: Error) => void>();
  private stop?: Unsubscribe;
  private started = false;
  private busy = false;
  private online = false;
  private ready = false;
  private remote = new Map<string, RecordData>();
  private revisions = new Map<string, number>();
  private tombstones = new Set<string>();
  private serial: Promise<void> = Promise.resolve();

  constructor(readonly uid: string, readonly kind: Kind) {}
  private get storeKey() { return `dailyhub_sync_v1_${this.uid}_${this.kind}`; }
  private get col() { return collection(db, 'users', this.uid, this.kind); }
  private get profileRef() { return doc(db, 'users', this.uid, 'settings', 'profile'); }
  private emit() { this.listeners.forEach(fn => fn([...this.state.records])); }
  private fail(e: unknown) {
    const error = e instanceof Error ? e : new Error(String(e));
    console.warn(`Sync ${this.kind}:`, error);
    this.errors.forEach(fn => fn(error));
  }
  private persist() { return AsyncStorage.setItem(this.storeKey, JSON.stringify(this.state)); }
  private enqueue(work: () => Promise<void>) {
    this.serial = this.serial.then(work).catch(e => this.fail(e));
    return this.serial;
  }
  private recompute() {
    const rows = new Map(this.remote);
    for (const pending of this.state.pending) {
      if (pending.data === null) rows.delete(pending.id);
      else rows.set(pending.id, pending.data);
    }
    this.state.records = [...rows.values()];
    this.emit();
  }
  private async start() {
    try {
      const raw = await AsyncStorage.getItem(this.storeKey);
      if (raw) {
        const parsed = JSON.parse(raw) as State;
        this.state = {
          records: Array.isArray(parsed.records) ? parsed.records : [],
          pending: Array.isArray(parsed.pending) ? parsed.pending : [],
          imported: !!parsed.imported,
        };
      }
      this.ready = true;
      this.emit();
      const listen = this.kind === 'profile' ? this.profileRef : this.col;
      this.stop = onSnapshot(listen as any, (snapshot: any) => {
        // Serialize snapshot handling with local edits; cache snapshots are not authoritative.
        this.enqueue(async () => {
          this.online = !snapshot.metadata.fromCache;
          if (!this.online) return;
          this.remote.clear();
          this.revisions.clear();
          this.tombstones.clear();
          const entries = this.kind === 'profile'
            ? (snapshot.exists() ? [{ id: 'profile', data: snapshot.data() }] : [])
            : snapshot.docs.map((d: any) => ({ id: d.id, data: d.data() }));
          for (const { id, data } of entries) {
            this.revisions.set(id, Number(data.syncRevision ?? 0));
            if (data.deleted) this.tombstones.add(id);
            else this.remote.set(id, { ...data, id });
          }
          if (!this.state.imported) await this.importLegacy();
          this.recompute();
          await this.persist();
          void this.flush();
        });
      }, (e: Error) => this.fail(e));
    } catch (e) { this.fail(e); }
  }
  private async importLegacy() {
    const raw = await AsyncStorage.getItem(legacyKeys[this.kind]);
    const legacy = raw ? JSON.parse(raw) : null;
    const items: RecordData[] = this.kind === 'profile'
      ? (legacy && typeof legacy === 'object' ? [{ ...legacy, id: 'profile' }] : [])
      : (Array.isArray(legacy) ? legacy.filter(x => x && x.id != null).map(clean) : []);
    for (const item of items) {
      // Never resurrect a cloud tombstone or import over an existing cloud record.
      if (this.tombstones.has(item.id) || this.state.pending.some(p => p.id === item.id)) continue;
      const existing = this.remote.get(item.id);
      if (!existing) {
        this.state.pending.push({ id: item.id, data: clean(item), base: 0, op: randomId() });
      } else if (!equal(existing, item)) {
        await this.archiveConflict(item, existing, 'legacy-import');
      }
    }
    this.state.imported = true;
    await this.persist();
  }
  private async archiveConflict(local: RecordData, remote: RecordData | null, reason: string) {
    const conflictRef = doc(db, 'users', this.uid, 'syncConflicts', `${this.kind}-${randomId()}`);
    await runTransaction(db, async tx => {
      tx.set(conflictRef, { kind: this.kind, originalId: local.id, local, remote, reason, createdAt: serverTimestamp() });
    });
  }
  private async flush() {
    if (this.busy || !this.online || !this.ready) return;
    this.busy = true;
    try {
      while (this.state.pending.length && this.online) {
        const change = this.state.pending[0];
        const target = this.kind === 'profile' ? this.profileRef : doc(this.col, change.id);
        const conflictRef = doc(db, 'users', this.uid, 'syncConflicts', `${this.kind}-${change.op}`);
        let result: 'applied' | 'conflict' = 'applied';
        let nextRevision = 0;
        await runTransaction(db, async tx => {
          const snap = await tx.get(target);
          const remote: RecordData | null = snap.exists()
            ? { ...snap.data(), id: change.id }
            : null;
          const revision = Number(snap.data()?.syncRevision ?? 0);
          // Legacy Firestore documents have revision 0 and are valid edit/delete targets.
          // A previously deleted cloud document is NOT a valid target for a stale create.
          if (revision !== change.base || (remote?.deleted && change.data !== null)) {
            result = 'conflict';
            tx.set(conflictRef, {
              kind: this.kind, originalId: change.id, local: change.data,
              remote, reason: 'concurrent-change', createdAt: serverTimestamp(),
            });
          } else {
            nextRevision = revision + 1;
            tx.set(target, {
              ...(change.data ? clean(change.data) : {}),
              deleted: change.data === null,
              ...(change.data === null ? { deletedAt: serverTimestamp() } : {}),
              syncRevision: nextRevision,
              serverUpdatedAt: serverTimestamp(),
            }, { merge: true });
          }
        });
        // Keep queued later operations on the same item based on the just-committed revision.
        this.state.pending.shift();
        if (result === 'applied') {
          this.revisions.set(change.id, nextRevision);
          if (change.data === null) {
            this.tombstones.add(change.id);
            this.remote.delete(change.id);
          } else {
            this.tombstones.delete(change.id);
            this.remote.set(change.id, change.data);
          }
          for (const p of this.state.pending) {
            if (p.id === change.id && p.base === change.base) p.base = nextRevision;
          }
        }
        this.recompute();
        await this.persist();
      }
    } catch (e) { this.fail(e); }
    finally { this.busy = false; }
  }
  subscribe(fn: (rows: RecordData[]) => void, onError?: (e: Error) => void) {
    this.listeners.add(fn);
    if (onError) this.errors.add(onError);
    fn([...this.state.records]);
    if (!this.started) { this.started = true; void this.start(); }
    return () => { this.listeners.delete(fn); if (onError) this.errors.delete(onError); };
  }
  async change(id: string, data: RecordData | null) {
    if (!this.started) { this.started = true; void this.start(); }
    // Wait for local state hydration and any in-progress snapshot processing.
    while (!this.ready) await new Promise(resolve => setTimeout(resolve, 10));
    await this.enqueue(async () => {
      const prior = [...this.state.pending].reverse().find(p => p.id === id);
      const base = prior?.base ?? this.revisions.get(id) ?? 0;
      this.state.pending.push({ id, data, base, op: randomId() });
      const next = new Map(this.state.records.map(r => [r.id, r]));
      if (data === null) next.delete(id); else next.set(id, data);
      this.state.records = [...next.values()];
      await this.persist();
      this.emit();
    });
    void this.flush();
  }
  current() { return [...this.state.records]; }
}
function channel(kind: Kind) {
  const uid = auth.currentUser?.uid;
  if (!uid) throw new Error('You must be signed in.');
  const key = `${uid}/${kind}`;
  if (!channels.has(key)) channels.set(key, new Channel(uid, kind));
  return channels.get(key)!;
}
export type DailyTask = { id: string; title: string; date: string; time?: string | null; allDay?: boolean; done: boolean };
export type DailyNote = { id: string; title: string; body: string; updatedAt: number };
export type DailyProfile = { name: string; notifications: boolean; weekStartsMonday: boolean };
export const subscribeToTasks = (cb: (rows: DailyTask[]) => void, err?: (e: Error) => void) => channel('tasks').subscribe(r => cb(r as DailyTask[]), err);
export const subscribeToNotes = (cb: (rows: DailyNote[]) => void, err?: (e: Error) => void) => channel('notes').subscribe(r => cb(r as DailyNote[]), err);
export const subscribeToProfile = (cb: (p: DailyProfile) => void, err?: (e: Error) => void) => channel('profile').subscribe(r => cb({ name: '', notifications: false, weekStartsMonday: false, ...(r[0] ?? {}) }), err);
export const addTask = (title: string, date: string, time: string | null = null, allDay: boolean = time === null) => {
  const id = randomId();
  return channel('tasks').change(id, {
    id, title: title.trim(), date, time: allDay ? null : time, allDay, done: false,
  });
};
export const toggleTask = (id: string, done: boolean) => { const item = channel('tasks').current().find(x => x.id === id); if (!item) throw Error('Task not found'); return channel('tasks').change(id, { ...item, done }); };
export const deleteTask = (id: string) => channel('tasks').change(id, null);
export const addNote = (title: string, body: string) => { const id = randomId(); return channel('notes').change(id, { id, title, body, updatedAt: Date.now() }); };
export const updateNote = (id: string, title: string, body: string) => channel('notes').change(id, { id, title, body, updatedAt: Date.now() });
export const removeNote = (id: string) => channel('notes').change(id, null);
export const saveProfile = (p: DailyProfile) => channel('profile').change('profile', { id: 'profile', ...p });
