import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, ScrollView, Pressable, StyleSheet,
  Alert, Platform, ActivityIndicator, KeyboardAvoidingView,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import {
  subscribeToTasks,
  addTask as addCloudTask,
  toggleTask as toggleCloudTask,
  deleteTask as deleteCloudTask,
  type DailyTask,
} from '../../lib/tasks';

const C = {
  background: '#F8F9FD', white: '#FFFFFF', primary: '#6C63FF',
  text: '#202238', muted: '#9699AB', border: '#EDF0F5',
};
type Filter = 'All' | 'Active' | 'Done';
type TimedTask = DailyTask & { time?: string | null; allDay?: boolean };

const formatDate = (date: Date) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
const parseDate = (value: string) => {
  const [year, month, day] = value.split('-').map(Number);
  return new Date(year, month - 1, day);
};
const formatTime = (date: Date) =>
  `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(2, '0')}`;
const displayTime = (value: string) => {
  const [hours, minutes] = value.split(':').map(Number);
  if (!Number.isFinite(hours) || !Number.isFinite(minutes)) return value;
  const date = new Date(2000, 0, 1, hours, minutes);
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
};
const displayDate = (date: Date) => date.toLocaleDateString('en-US', {
  weekday: 'long', month: 'long', day: 'numeric', year: 'numeric',
});
function showMessage(title: string, message: string) {
  if (Platform.OS === 'web') {
    window.alert(`${title}\n${message}`);
  } else {
    Alert.alert(title, message);
  }
}

function TaskDateTimePicker({ date, mode, onChange }: {
  date: Date;
  mode: 'date' | 'time';
  onChange: (date: Date) => void;
}) {
  if (Platform.OS === 'web') {
    return (
      <View style={styles.webDateWrapper}>
        {React.createElement('input', {
          type: mode,
          value: mode === 'date' ? formatDate(date) : formatTime(date),
          onChange: (event: any) => {
            const value = event?.target?.value;
            if (!value) return;
            const next = new Date(date);
            if (mode === 'date') {
              const parsed = parseDate(value);
              if (Number.isNaN(parsed.getTime())) return;
              next.setFullYear(parsed.getFullYear(), parsed.getMonth(), parsed.getDate());
            } else {
              const [hours, minutes] = value.split(':').map(Number);
              if (!Number.isFinite(hours) || !Number.isFinite(minutes)) return;
              next.setHours(hours, minutes, 0, 0);
            }
            onChange(next);
          },
          style: {
            width: '100%', boxSizing: 'border-box', padding: '14px',
            fontSize: '15px', color: '#202238', backgroundColor: '#F7F8FC',
            border: '1px solid #EDF0F5', borderRadius: '12px', fontFamily: 'inherit',
          },
        })}
      </View>
    );
  }
  const NativeDateTimePicker = require('@react-native-community/datetimepicker').default;
  return (
    <NativeDateTimePicker
      value={date}
      mode={mode}
      display={Platform.OS === 'ios' ? 'spinner' : 'default'}
      onChange={(_event: any, selected?: Date) => {
        if (selected) onChange(selected);
      }}
      themeVariant="light"
      accentColor={C.primary}
    />
  );
}

export default function TasksScreen() {
  const [tasks, setTasks] = useState<DailyTask[]>([]);
  const [title, setTitle] = useState('');
  const [date, setDate] = useState(new Date());
  const [allDay, setAllDay] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [filter, setFilter] = useState<Filter>('All');
  const [loaded, setLoaded] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let unsubscribe: (() => void) | undefined;
    try {
      unsubscribe = subscribeToTasks(
        cloudTasks => { setTasks(cloudTasks); setLoaded(true); },
        error => {
          console.error('Firestore subscription error:', error);
          setLoaded(true);
          showMessage('Unable to load tasks', error.message);
        }
      );
    } catch (error: any) {
      setLoaded(true);
      showMessage('Unable to connect to Firestore', error?.message || 'Please sign in and try again.');
    }
    return () => unsubscribe?.();
  }, []);

  const handleAddTask = async () => {
    const trimmed = title.trim();
    if (!trimmed) {
      showMessage('Missing Task', 'Please enter a task name.');
      return;
    }
    if (saving) return;
    setSaving(true);
    try {
      await addCloudTask(trimmed, formatDate(date), allDay ? null : formatTime(date), allDay);
      setTitle('');
      setDate(new Date());
      setAllDay(false);
      setShowDatePicker(false);
      setShowTimePicker(false);
    } catch (error: any) {
      showMessage('Unable to add task', error?.message || 'Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleTask = async (task: DailyTask) => {
    if (saving) return;
    setSaving(true);
    try {
      await toggleCloudTask(task.id, !task.done);
    } catch (error: any) {
      showMessage('Unable to update task', error?.message || 'Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteTask = (id: string) => {
    const remove = async () => {
      if (saving) return;
      setSaving(true);
      try {
        await deleteCloudTask(id);
      } catch (error: any) {
        showMessage('Unable to delete task', error?.message || 'Please try again.');
      } finally {
        setSaving(false);
      }
    };
    if (Platform.OS === 'web') {
      if (window.confirm('Permanently delete this task?')) void remove();
      return;
    }
    Alert.alert('Delete Task?', 'This task will be permanently removed.', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => void remove() },
    ]);
  };

  const completed = tasks.filter(task => task.done).length;
  const progress = tasks.length ? (completed / tasks.length) * 100 : 0;
  const visibleTasks = tasks
    .filter(task => filter === 'Active' ? !task.done : filter === 'Done' ? task.done : true)
    .sort((a, b) => {
      const left = a as TimedTask;
      const right = b as TimedTask;
      return a.date.localeCompare(b.date) || (left.time ?? '').localeCompare(right.time ?? '');
    });

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content}>
          <Text style={styles.kicker}>STAY PRODUCTIVE</Text>
          <Text style={styles.heading}>My Tasks </Text>
          <Text style={styles.subtitle}>Keep your day on track.</Text>

          <View style={styles.summaryCard}>
            <View style={styles.summaryRow}>
              <View style={{ flex: 1 }}>
                <Text style={styles.summaryTitle}>Your Progress</Text>
                <Text style={styles.summarySubtitle}>
                  {tasks.length === 0 ? 'Add your first task to begin.' : completed === tasks.length ? 'Amazing! All tasks completed.' : 'Every completed task counts.'}
                </Text>
              </View>
              <View style={styles.progressCircle}>
                <Text style={styles.progressPercent}>{Math.round(progress)}%</Text>
              </View>
            </View>
            <View style={styles.progressTrack}>
              <View style={[styles.progressFill, { width: `${progress}%` }]} />
            </View>
            <Text style={styles.progressFooter}>{completed} of {tasks.length} tasks completed</Text>
          </View>

          <View style={styles.createCard}>
            <Text style={styles.cardTitle}>Create a Task</Text>
            <Text style={styles.fieldLabel}>Task Name</Text>
            <TextInput
              style={styles.input}
              placeholder="What needs to be done?"
              placeholderTextColor={C.muted}
              value={title}
              onChangeText={setTitle}
              returnKeyType="done"
              maxLength={150}
            />

            <Text style={styles.fieldLabel}>Due Date</Text>
            <Pressable style={styles.dateButton} onPress={() => {
              setShowDatePicker(previous => !previous);
              setShowTimePicker(false);
            }}>
              <View style={styles.dateIcon}>
                <Ionicons name="calendar-outline" size={23} color={C.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.dateCaption}>Selected Date</Text>
                <Text style={styles.dateValue}>{displayDate(date)}</Text>
              </View>
              <Ionicons name={showDatePicker ? 'chevron-up' : 'chevron-down'} size={20} color={C.muted} />
            </Pressable>
            {showDatePicker && (
              <View style={styles.pickerContainer}>
                <TaskDateTimePicker date={date} mode="date" onChange={setDate} />
                <Pressable style={styles.pickerDone} onPress={() => setShowDatePicker(false)}>
                  <Text style={styles.pickerDoneText}>Done</Text>
                </Pressable>
              </View>
            )}

            <Pressable
              style={styles.allDayRow}
              accessibilityRole="checkbox"
              accessibilityState={{ checked: allDay }}
              onPress={() => {
                setAllDay(previous => !previous);
                setShowTimePicker(false);
              }}
            >
              <Ionicons name={allDay ? 'checkbox' : 'square-outline'} size={25} color={C.primary} />
              <View style={{ flex: 1 }}>
                <Text style={styles.allDayTitle}>All Day</Text>
                <Text style={styles.allDaySubtitle}>No specific time needed</Text>
              </View>
            </Pressable>

            {!allDay && (
              <>
                <Text style={styles.fieldLabel}>Due Time</Text>
                <Pressable style={styles.dateButton} onPress={() => {
                  setShowTimePicker(previous => !previous);
                  setShowDatePicker(false);
                }}>
                  <View style={styles.dateIcon}>
                    <Ionicons name="time-outline" size={23} color={C.primary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.dateCaption}>Selected Time</Text>
                    <Text style={styles.dateValue}>
                      {date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                    </Text>
                  </View>
                  <Ionicons name={showTimePicker ? 'chevron-up' : 'chevron-down'} size={20} color={C.muted} />
                </Pressable>
                {showTimePicker && (
                  <View style={styles.pickerContainer}>
                    <TaskDateTimePicker date={date} mode="time" onChange={setDate} />
                    <Pressable style={styles.pickerDone} onPress={() => setShowTimePicker(false)}>
                      <Text style={styles.pickerDoneText}>Done</Text>
                    </Pressable>
                  </View>
                )}
              </>
            )}

            <Pressable style={[styles.addButton, (saving || !loaded) && { opacity: 0.6 }]} disabled={saving || !loaded} onPress={handleAddTask}>
              {saving ? <ActivityIndicator color="white" /> : <Ionicons name="add-circle-outline" size={22} color="white" />}
              <Text style={styles.addButtonText}>{saving ? 'Saving...' : 'Add Task'}</Text>
            </Pressable>
          </View>

          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>My Task List</Text>
            <Text style={styles.taskCount}>{tasks.length} Tasks</Text>
          </View>
          <View style={styles.filters}>
            {(['All', 'Active', 'Done'] as const).map(item => (
              <Pressable key={item} style={[styles.filterButton, filter === item && styles.activeFilter]} onPress={() => setFilter(item)}>
                <Text style={[styles.filterText, filter === item && styles.activeFilterText]}>{item}</Text>
              </Pressable>
            ))}
          </View>

          {!loaded ? (
            <ActivityIndicator size="large" color={C.primary} style={{ marginTop: 30 }} />
          ) : visibleTasks.length === 0 ? (
            <View style={styles.emptyCard}>
              <View style={styles.emptyIcon}>
                <Ionicons name="checkmark-done-outline" size={30} color={C.primary} />
              </View>
              <Text style={styles.emptyTitle}>
                {filter === 'Done' ? 'No completed tasks' : filter === 'Active' ? 'No active tasks' : 'No tasks yet'}
              </Text>
              <Text style={styles.emptySubtitle}>
                {filter === 'All' ? 'Create your first task above!' : 'Nothing to show in this category.'}
              </Text>
            </View>
          ) : visibleTasks.map((task, index) => {
            const iconColors = ['#EEE9FF', '#E4F1FF', '#FFF0E2', '#E5F7EF'];
            const timed = task as TimedTask;
            const dateText = new Date(`${task.date}T12:00:00`).toLocaleDateString('en-US', {
              month: 'short', day: 'numeric', year: 'numeric',
            });
            const timeText = timed.allDay ? ' · All day' : timed.time ? ` · ${displayTime(timed.time)}` : '';
            return (
              <View key={task.id} style={styles.taskCard}>
                <Pressable onPress={() => handleToggleTask(task)} disabled={saving} hitSlop={8}>
                  <Ionicons name={task.done ? 'checkmark-circle' : 'ellipse-outline'} size={27} color={task.done ? C.primary : '#CBD0DC'} />
                </Pressable>
                <View style={[styles.taskIcon, { backgroundColor: iconColors[index % iconColors.length] }]}>
                  <Ionicons name="calendar-outline" size={21} color={C.primary} />
                </View>
                <View style={styles.taskInfo}>
                  <Text style={[styles.taskTitle, task.done && styles.completedTask]} numberOfLines={2}>{task.title}</Text>
                  <Text style={styles.taskDate}>{dateText}{timeText}</Text>
                </View>
                <Pressable onPress={() => handleDeleteTask(task.id)} disabled={saving} hitSlop={8} accessibilityRole="button" accessibilityLabel={`Delete ${task.title}`}>
                  <Ionicons name="trash-outline" size={20} color="#F47A87" />
                </Pressable>
              </View>
            );
          })}
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.background },
  content: { paddingHorizontal: 22, paddingTop: 20, paddingBottom: 45, gap: 15 },
  kicker: { color: C.primary, fontSize: 11, fontWeight: '800', letterSpacing: 2 },
  heading: { color: C.text, fontSize: 31, fontWeight: '900' },
  subtitle: { color: C.muted, fontSize: 13 },
  summaryCard: { backgroundColor: C.primary, borderRadius: 24, padding: 23, marginTop: 12 },
  summaryRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  summaryTitle: { color: C.white, fontSize: 19, fontWeight: '800' },
  summarySubtitle: { color: '#E1DEFF', fontSize: 12, marginTop: 7, maxWidth: 210 },
  progressCircle: { width: 66, height: 66, borderRadius: 33, borderWidth: 5, borderColor: '#A9A3FF', alignItems: 'center', justifyContent: 'center' },
  progressPercent: { color: C.white, fontSize: 16, fontWeight: '900' },
  progressTrack: { height: 9, borderRadius: 10, backgroundColor: '#9690FF', marginTop: 22, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: C.white, borderRadius: 10 },
  progressFooter: { color: '#E1DEFF', fontSize: 12, marginTop: 10 },
  createCard: { backgroundColor: C.white, borderRadius: 22, padding: 18, gap: 12 },
  cardTitle: { color: C.text, fontSize: 18, fontWeight: '800', marginBottom: 4 },
  fieldLabel: { color: '#777B91', fontSize: 12, fontWeight: '700' },
  input: { backgroundColor: '#F7F8FC', borderRadius: 14, padding: 16, color: C.text, fontSize: 15 },
  dateButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F7F8FC', borderRadius: 16, padding: 12, gap: 12 },
  dateIcon: { width: 46, height: 46, borderRadius: 14, backgroundColor: '#EEE9FF', alignItems: 'center', justifyContent: 'center' },
  dateCaption: { color: C.muted, fontSize: 11, fontWeight: '600', marginBottom: 4 },
  dateValue: { color: C.text, fontSize: 14, fontWeight: '800' },
  pickerContainer: { backgroundColor: C.white, borderRadius: 18, paddingVertical: 8, overflow: 'hidden' },
  webDateWrapper: { paddingHorizontal: 12, paddingVertical: 8 },
  pickerDone: { backgroundColor: C.primary, padding: 13, borderRadius: 12, alignItems: 'center', marginHorizontal: 12, marginBottom: 8 },
  pickerDoneText: { color: C.white, fontSize: 14, fontWeight: '800' },
  allDayRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F7F8FC', borderRadius: 15, padding: 16, gap: 12 },
  allDayTitle: { color: C.text, fontSize: 15, fontWeight: '700' },
  allDaySubtitle: { color: C.muted, fontSize: 12, marginTop: 3 },
  addButton: { backgroundColor: C.primary, padding: 16, borderRadius: 15, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 8, marginTop: 5 },
  addButtonText: { color: C.white, fontSize: 15, fontWeight: '800' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 14 },
  sectionTitle: { color: C.text, fontSize: 19, fontWeight: '800' },
  taskCount: { color: C.muted, fontSize: 12, fontWeight: '600' },
  filters: { flexDirection: 'row', gap: 10 },
  filterButton: { paddingHorizontal: 20, paddingVertical: 11, borderRadius: 20, backgroundColor: C.white },
  activeFilter: { backgroundColor: C.primary },
  filterText: { color: '#777B91', fontWeight: '700', fontSize: 13 },
  activeFilterText: { color: C.white },
  taskCard: { backgroundColor: C.white, borderRadius: 18, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
  taskIcon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  taskInfo: { flex: 1 },
  taskTitle: { color: C.text, fontSize: 15, fontWeight: '700' },
  completedTask: { color: C.muted, textDecorationLine: 'line-through' },
  taskDate: { color: C.muted, fontSize: 12, marginTop: 5 },
  emptyCard: { backgroundColor: C.white, borderRadius: 22, padding: 32, alignItems: 'center', gap: 10 },
  emptyIcon: { width: 60, height: 60, borderRadius: 20, backgroundColor: '#EEE9FF', alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { color: C.text, fontSize: 18, fontWeight: '800' },
  emptySubtitle: { color: C.muted, fontSize: 13, textAlign: 'center' },
});
