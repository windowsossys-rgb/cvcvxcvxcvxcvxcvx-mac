
import React, { useState } from 'react';
import {
  View,
  Text,
  Pressable,
  Alert,
  Platform,
  StyleSheet,
} from 'react-native';
import { addTask } from '../lib/tasks';
import { auth } from '../lib/firebase';

export default function FirestoreTest() {
  const [result, setResult] = useState('Not tested yet');

  const testFirestore = async () => {
    try {
      if (!auth.currentUser) {
        setResult('Please sign in first.');
        return;
      }

      const task = await addTask(
        'My first cloud task',
        '2026-10-15'
      );

      setResult(`Success! Task ID: ${task.id}`);
    } catch (error: any) {
      setResult(`Error: ${error.message}`);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Firestore Connection Test</Text>

      <Text style={styles.status}>{result}</Text>

      <Pressable
        style={styles.button}
        onPress={testFirestore}
      >
        <Text style={styles.buttonText}>
          Test Firestore
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FD',
    justifyContent: 'center',
    padding: 24,
  },
  title: {
    fontSize: 25,
    fontWeight: '800',
    color: '#22243A',
    marginBottom: 20,
  },
  status: {
    fontSize: 15,
    marginBottom: 25,
    color: '#555',
  },
  button: {
    backgroundColor: '#6C63FF',
    padding: 18,
    borderRadius: 15,
    alignItems: 'center',
  },
  buttonText: {
    color: 'white',
    fontWeight: '800',
  },
});
