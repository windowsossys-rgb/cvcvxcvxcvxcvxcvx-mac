// Native authentication persistence is controlled by the Firebase Auth adapter.
// The current native Firebase configuration may not persist across app restarts.
export async function setRememberMe(_remember: boolean): Promise<void> {
  // Native session-only persistence requires a separate auth-storage implementation.
}
